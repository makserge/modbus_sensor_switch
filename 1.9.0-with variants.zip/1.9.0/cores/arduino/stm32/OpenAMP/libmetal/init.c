#ifdef VIRTIOCON

#include "libmetal/lib/init.c"

#endif /* VIRTIOCON */
