#ifdef VIRTIOCON

#include "virtio_config.h"
#include "open-amp/lib/virtio/virtqueue.c"

#endif /* VIRTIOCON */
